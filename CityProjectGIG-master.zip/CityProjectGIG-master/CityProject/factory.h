#ifndef FACTORY_H
#define FACTORY_H


#include "building.h"

class Factory : public Building
{
private :
public:
    Factory(QVector3D center);
};

#endif // FACTORY_H
