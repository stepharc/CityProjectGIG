#ifndef MAINWIN_H
#define MAINWIN_H

#include <QMainWindow>
#include <QObject>

class MainWin
{
public:
    MainWin();
};

#endif // MAINWIN_H