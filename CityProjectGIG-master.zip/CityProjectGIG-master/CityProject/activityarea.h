#ifndef ACTIVITYAREA_H
#define ACTIVITYAREA_H

#include "district.h"

class ActivityArea : public District
{
public:
    ActivityArea(int c, int r, float rsw, float rsd);
};

#endif // ACTIVITYAREA_H
