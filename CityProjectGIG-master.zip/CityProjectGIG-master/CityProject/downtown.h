#ifndef DOWNTOWN_H
#define DOWNTOWN_H

#include "district.h"

class Downtown : public District
{
public:
    Downtown(int c, int r, float rsw, float rsd);
};

#endif // DOWNTOWN_H
