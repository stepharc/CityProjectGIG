#ifndef TOWER_H
#define TOWER_H

#include "building.h"

class Tower : public Building
{
private :

public:
    Tower(QVector3D center);
};

#endif // TOWER_H
